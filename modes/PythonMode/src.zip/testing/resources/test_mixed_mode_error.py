# should throw a mixed mode exception

size(400,400)
def setup():
    x = 0

def draw():
    rect(200,200,100,100)